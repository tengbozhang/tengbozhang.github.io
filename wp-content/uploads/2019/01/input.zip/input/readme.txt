本数据包含川普和尼古拉斯凯奇的脸部图片训练数据，
用于构建深度学习网络

由春江暮客从网络下载后整理出来，
原下载地址为https://cdn-05.anonfile.com/p7w3m0d5be/6ac9fc34-1547775034/face-swap.zip
春江暮客下载地址：
https://www.bobobk.com/258.html查看


使用方法，
下载到faceswap程序目录下，解压即可，详情请看博客介绍
https://www.bobobk.com/258.html
